
import { GoogleGenAI, GenerateContentResponse, Part, GenerateContentParameters, Chat } from "@google/genai";
import { GEMINI_TEXT_MODEL, IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { GeminiResponseContent, GroundingChunk } from "../types";

let ai: GoogleGenAI | null = null;
if (IS_API_KEY_CONFIGURED && process.env.API_KEY) {
  ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
}

export const generateText = async (prompt: string, useGoogleSearch: boolean = false): Promise<GeminiResponseContent> => {
  if (!ai) {
    console.error(GEMINI_API_KEY_ERROR_MESSAGE);
    throw new Error(GEMINI_API_KEY_ERROR_MESSAGE);
  }

  const params: GenerateContentParameters = {
    model: GEMINI_TEXT_MODEL,
    contents: prompt,
  };

  if (useGoogleSearch) {
    params.config = { tools: [{googleSearch: {}}] };
  } else {
     params.config = { thinkingConfig: { thinkingBudget: 0 } }; // Low latency for general text
  }

  try {
    const response: GenerateContentResponse = await ai.models.generateContent(params);
    const text = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources: GroundingChunk[] | undefined = groundingMetadata?.groundingChunks;
    
    return { text, candidates: response.candidates };
  } catch (error) {
    console.error("Gemini API error:", error);
    if (error instanceof Error) {
        throw new Error(`Gemini API request failed: ${error.message}`);
    }
    throw new Error("Gemini API request failed with an unknown error.");
  }
};


export const startChat = (): Chat | null => {
  if (!ai) {
    console.error(GEMINI_API_KEY_ERROR_MESSAGE);
    // Optionally, you could throw an error here or return null to be handled by the caller
    return null; 
  }
  return ai.chats.create({
    model: GEMINI_TEXT_MODEL,
    config: {
      systemInstruction: 'You are a helpful assistant specialized in supply chain sustainability.',
    },
  });
};

export const sendMessageInChat = async (chat: Chat, message: string): Promise<GeminiResponseContent> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return { text: response.text, candidates: response.candidates };
  } catch (error) {
    console.error("Gemini Chat API error:", error);
     if (error instanceof Error) {
        throw new Error(`Gemini Chat API request failed: ${error.message}`);
    }
    throw new Error("Gemini Chat API request failed with an unknown error.");
  }
};

// Helper to parse JSON, removing potential markdown fences
export const parseJsonFromGeminiResponse = <T,>(responseText: string): T | null => {
  let jsonStr = responseText.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches ```json ... ``` or ``` ... ```
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }

  try {
    return JSON.parse(jsonStr) as T;
  } catch (e) {
    console.error("Failed to parse JSON response from Gemini:", e, "Original text:", responseText);
    return null;
  }
};
