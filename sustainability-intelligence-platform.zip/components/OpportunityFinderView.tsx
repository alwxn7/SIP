
import React, { useState, useCallback } from 'react';
import { generateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import GeminiResponseModal from './GeminiResponseModal';
import { IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { SparklesIcon } from './icons';
import { GroundingChunk } from '../types';

const OpportunityFinderView: React.FC = () => {
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [modalSources, setModalSources] = useState<GroundingChunk[] | undefined>(undefined);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim() || !IS_API_KEY_CONFIGURED) {
      if (!IS_API_KEY_CONFIGURED) {
        setError(GEMINI_API_KEY_ERROR_MESSAGE);
        setModalTitle("API Key Error");
        setModalContent(GEMINI_API_KEY_ERROR_MESSAGE);
        setModalOpen(true);
      }
      return;
    }

    setIsLoading(true);
    setError(null);
    setModalOpen(true);
    setModalTitle("AI Sustainability Opportunities");
    setModalContent('');
    setModalSources(undefined);

    const prompt = `
      Based on the following scenario or area of focus in a supply chain, identify 3-5 innovative and actionable sustainability opportunities. 
      For each opportunity, provide a brief explanation of its potential impact (environmental, social, economic) and key steps for implementation.
      Focus on areas like circular economy, renewable energy, waste reduction, ethical sourcing, community engagement, or technological advancements.
      Scenario/Focus: "${userInput}"
      Consider if this information is recent and if Google Search might be helpful.
    `;

    try {
      const result = await generateText(prompt, true); // Using Google Search for opportunity finding
      setModalContent(result.text);
       if (result.candidates && result.candidates[0]?.groundingMetadata?.groundingChunks) {
        setModalSources(result.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to get opportunities from AI.');
      setModalContent(e.message || 'Failed to get opportunities from AI.');
    } finally {
      setIsLoading(false);
    }
  }, [userInput]);

  return (
    <div className="p-8">
      <h2 className="text-3xl font-semibold text-white mb-6">Opportunity Finder</h2>
      
      <form onSubmit={handleSubmit} className="bg-base-200 p-6 rounded-xl shadow-lg space-y-4">
        <div>
          <label htmlFor="scenario" className="block text-sm font-medium text-gray-300 mb-1">
            Describe your supply chain focus, product, or sustainability challenge:
          </label>
          <textarea
            id="scenario"
            rows={5}
            className="w-full p-3 bg-base-300 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-brand-primary outline-none placeholder-gray-500"
            placeholder="e.g., 'Reducing carbon footprint in apparel manufacturing', 'Improving ethical sourcing for coffee beans', 'Implementing circular economy for electronics'"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
          />
        </div>
        
        {!IS_API_KEY_CONFIGURED && (
          <div className="p-3 bg-yellow-900 border border-yellow-700 text-yellow-200 rounded-md text-sm">
            {GEMINI_API_KEY_ERROR_MESSAGE} AI features for analysis are disabled.
          </div>
        )}

        <button 
          type="submit"
          disabled={isLoading || !userInput.trim() || !IS_API_KEY_CONFIGURED}
          className="w-full flex items-center justify-center bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-3 px-4 rounded-lg transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner /> : <><SparklesIcon className="w-5 h-5 mr-2" /> Find Opportunities with AI</>}
        </button>
      </form>

      <GeminiResponseModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        content={modalContent}
        isLoading={isLoading}
        error={error}
        sources={modalSources}
      />
    </div>
  );
};

export default OpportunityFinderView;
