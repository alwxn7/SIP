
import React from 'react';
import { CloseIcon } from './icons';
import { GroundingChunk } from '../types';

interface GeminiResponseModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  content: string;
  isLoading: boolean;
  error?: string | null;
  sources?: GroundingChunk[];
}

const GeminiResponseModal: React.FC<GeminiResponseModalProps> = ({ isOpen, onClose, title, content, isLoading, error, sources }) => {
  if (!isOpen) return null;

  const renderSources = () => {
    if (!sources || sources.length === 0) return null;
    const webSources = sources.filter(s => s.web && s.web.uri);
    if (webSources.length === 0) return null;

    return (
      <div className="mt-4 pt-4 border-t border-base-300">
        <h4 className="text-sm font-semibold text-gray-400 mb-2">Sources:</h4>
        <ul className="list-disc list-inside text-xs space-y-1">
          {webSources.map((source, index) => (
            source.web && (
              <li key={index}>
                <a 
                  href={source.web.uri} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-brand-primary hover:text-brand-secondary underline"
                  title={source.web.title}
                >
                  {source.web.title || source.web.uri}
                </a>
              </li>
            )
          ))}
        </ul>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-base-200 p-6 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>
        {isLoading && (
          <div className="flex justify-center items-center h-32">
            <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-brand-primary"></div>
            <p className="ml-4 text-lg">Generating insights...</p>
          </div>
        )}
        {error && <p className="text-red-400 bg-red-900 p-3 rounded-md">{error}</p>}
        {!isLoading && !error && (
          <div className="text-gray-300 whitespace-pre-wrap">{content}</div>
        )}
        {!isLoading && !error && renderSources()}
         <button
            onClick={onClose}
            className="mt-6 w-full bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-2 px-4 rounded-md transition duration-150 ease-in-out"
          >
            Close
          </button>
      </div>
    </div>
  );
};

export default GeminiResponseModal;
