
import React from 'react';
import MetricCard from './MetricCard';
import ChartComponent from './ChartComponent';
import { MOCK_DASHBOARD_METRICS, MOCK_CARBON_BREAKDOWN, MOCK_WATER_USAGE_TREND } from '../constants';
import { SustainabilityMetric, ChartDataPoint, TimeSeriesDataPoint } from '../types';

const DashboardView: React.FC = () => {
  return (
    <div className="p-8 space-y-8">
      <h2 className="text-3xl font-semibold text-white">Sustainability Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {MOCK_DASHBOARD_METRICS.map((metric: SustainabilityMetric) => (
          <MetricCard key={metric.id} metric={metric} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartComponent 
          title="Carbon Footprint Breakdown (tCO2e)" 
          data={MOCK_CARBON_BREAKDOWN as ChartDataPoint[]} 
          type="pie"
          dataKey="value"
          nameKey="name"
        />
        <ChartComponent 
          title="Water Usage Trend (m³ x1000)" 
          data={MOCK_WATER_USAGE_TREND as TimeSeriesDataPoint[]} 
          type="line"
          dataKey="value"
        />
      </div>

      <div className="bg-base-200 p-6 rounded-xl shadow-lg">
        <h3 className="text-xl font-semibold text-gray-200 mb-3">Recent Alerts & Notifications</h3>
        <ul className="space-y-2 text-sm">
          <li className="flex items-center p-2 bg-yellow-700 bg-opacity-30 rounded-md">
            <span className="text-yellow-400 mr-2">⚠️</span>
            High risk deforestation alert for AgroSource Brazil.
          </li>
          <li className="flex items-center p-2 bg-emerald-700 bg-opacity-30 rounded-md">
            <span className="text-emerald-400 mr-2">✅</span>
            EcoTextiles Inc. achieved 5% reduction in water usage this quarter.
          </li>
          <li className="flex items-center p-2 bg-orange-700 bg-opacity-30 rounded-md">
            <span className="text-orange-400 mr-2">🔔</span>
            Upcoming audit for Global Metals Co. labor practices.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default DashboardView;
