import React, { useState, useCallback } from 'react';
import { generateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import GeminiResponseModal from './GeminiResponseModal';
import { IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { SparklesIcon } from './icons';
import { EmissionEstimateRequest, GroundingChunk } from '../types';

const EmissionsEstimatorView: React.FC = () => {
  const [formData, setFormData] = useState<EmissionEstimateRequest>({
    productName: '',
    category: 'Apparel',
    weightKg: 0,
    primaryMaterial: '',
    manufacturingLocation: '',
    transportMode: 'Sea',
    transportDistanceKm: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [modalSources, setModalSources] = useState<GroundingChunk[] | undefined>(undefined);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'weightKg' || name === 'transportDistanceKm' ? parseFloat(value) : value }));
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!IS_API_KEY_CONFIGURED) {
      setError(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalTitle("API Key Error");
      setModalContent(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalOpen(true);
      return;
    }
    if (!formData.productName || formData.weightKg <= 0 || !formData.primaryMaterial || !formData.manufacturingLocation || formData.transportDistanceKm <= 0) {
        setError("Please fill in all required fields with valid values.");
        setModalTitle("Input Error");
        setModalContent("Please fill in all required fields: Product Name, Weight (>0), Primary Material, Manufacturing Location, and Transport Distance (>0).");
        setModalOpen(true);
        return;
    }


    setIsLoading(true);
    setError(null);
    setModalOpen(true);
    setModalTitle(`Emissions Estimate: ${formData.productName}`);
    setModalContent('');
    setModalSources(undefined);

    const prompt = `
      Estimate the carbon footprint (in kg CO2e) for a product with the following details:
      Product Name: "${formData.productName}"
      Category: ${formData.category}
      Weight: ${formData.weightKg} kg
      Primary Material: "${formData.primaryMaterial}"
      Manufacturing Location: "${formData.manufacturingLocation}" (Consider typical energy mix for this location if known, otherwise use global average industrial emissions factors.)
      Transportation Mode: ${formData.transportMode}
      Transportation Distance: ${formData.transportDistanceKm} km

      Provide:
      1. Total estimated CO2e.
      2. A brief breakdown (e.g., manufacturing emissions, material production emissions, transportation emissions).
      3. Key assumptions made during the estimation.
      
      Use Google Search if needed for specific emission factors (e.g., for materials, manufacturing processes in the given location, or transport modes) and cite key sources if possible.
      Present the result clearly.
    `;

    try {
      const result = await generateText(prompt, true);
      setModalContent(result.text);
      if (result.candidates && result.candidates[0]?.groundingMetadata?.groundingChunks) {
        setModalSources(result.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to get emissions estimate from AI.');
      setModalContent(e.message || 'Failed to get emissions estimate from AI.');
    } finally {
      setIsLoading(false);
    }
  }, [formData]);

  const inputClass = "w-full p-3 bg-base-300 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-brand-primary outline-none placeholder-gray-500";
  const labelClass = "block text-sm font-medium text-gray-300 mb-1";

  return (
    <div className="p-8">
      <h2 className="text-3xl font-semibold text-white mb-6">Emissions Estimator</h2>
      
      <form onSubmit={handleSubmit} className="bg-base-200 p-6 rounded-xl shadow-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="productName" className={labelClass}>Product Name *</label>
            <input type="text" name="productName" id="productName" value={formData.productName} onChange={handleInputChange} className={inputClass} placeholder="e.g., Organic Cotton T-Shirt" required />
          </div>
          <div>
            <label htmlFor="category" className={labelClass}>Category *</label>
            <select name="category" id="category" value={formData.category} onChange={handleInputChange} className={inputClass} required>
              <option value="Apparel">Apparel</option>
              <option value="Electronics">Electronics</option>
              <option value="Food & Beverage">Food & Beverage</option>
              <option value="Automotive">Automotive</option>
              <option value="Building Materials">Building Materials</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div>
            <label htmlFor="weightKg" className={labelClass}>Weight (kg) *</label>
            <input type="number" name="weightKg" id="weightKg" value={formData.weightKg} onChange={handleInputChange} className={inputClass} placeholder="e.g., 0.2" min="0.01" step="0.01" required />
          </div>
           <div>
            <label htmlFor="primaryMaterial" className={labelClass}>Primary Material *</label>
            <input type="text" name="primaryMaterial" id="primaryMaterial" value={formData.primaryMaterial} onChange={handleInputChange} className={inputClass} placeholder="e.g., Organic Cotton" required />
          </div>
          <div>
            <label htmlFor="manufacturingLocation" className={labelClass}>Manufacturing Location *</label>
            <input type="text" name="manufacturingLocation" id="manufacturingLocation" value={formData.manufacturingLocation} onChange={handleInputChange} className={inputClass} placeholder="e.g., Vietnam" required />
          </div>
          <div>
            <label htmlFor="transportMode" className={labelClass}>Transportation Mode *</label>
            <select name="transportMode" id="transportMode" value={formData.transportMode} onChange={handleInputChange} className={inputClass} required>
              <option value="Sea">Sea Freight</option>
              <option value="Air">Air Freight</option>
              <option value="Rail">Rail Freight</option>
              <option value="Truck">Truck/Road Freight</option>
            </select>
          </div>
          <div>
            <label htmlFor="transportDistanceKm" className={labelClass}>Transportation Distance (km) *</label>
            <input type="number" name="transportDistanceKm" id="transportDistanceKm" value={formData.transportDistanceKm} onChange={handleInputChange} className={inputClass} placeholder="e.g., 15000" min="1" required />
          </div>
        </div>
        
        {!IS_API_KEY_CONFIGURED && (
          <div className="p-3 bg-yellow-900 border border-yellow-700 text-yellow-200 rounded-md text-sm">
            {GEMINI_API_KEY_ERROR_MESSAGE} AI features for estimation are disabled.
          </div>
        )}

        <button 
          type="submit"
          disabled={isLoading || !IS_API_KEY_CONFIGURED}
          className="w-full flex items-center justify-center bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-3 px-4 rounded-lg transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner /> : <><SparklesIcon className="w-5 h-5 mr-2" /> Estimate Emissions with AI</>}
        </button>
      </form>

      <GeminiResponseModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        content={modalContent}
        isLoading={isLoading}
        error={error}
        sources={modalSources}
      />
    </div>
  );
};

export default EmissionsEstimatorView;