
import React, { useState, useCallback } from 'react';
import { MOCK_RISKS, MOCK_SUPPLIERS, IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { Risk, Supplier, GroundingChunk } from '../types';
import { generateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import GeminiResponseModal from './GeminiResponseModal';
import { SparklesIcon } from './icons';

interface RiskItemProps {
  risk: Risk;
  onAnalyze: (risk: Risk) => void;
  apiKeyConfigured: boolean;
}

const RiskItem: React.FC<RiskItemProps> = ({ risk, onAnalyze, apiKeyConfigured }) => {
  const supplier = MOCK_SUPPLIERS.find(s => s.id === risk.supplierId);
  const severityColor = risk.severity === 'High' ? 'bg-red-600' : risk.severity === 'Medium' ? 'bg-yellow-500' : 'bg-emerald-500';

  return (
    <div className="bg-base-200 p-4 rounded-lg shadow-md">
      <div className="flex justify-between items-start">
        <h3 className="text-lg font-semibold text-white mb-1">{risk.description}</h3>
        <span className={`px-2 py-1 text-xs font-semibold text-white rounded-full ${severityColor}`}>{risk.severity}</span>
      </div>
      <p className="text-sm text-gray-400">Category: {risk.category}</p>
      {supplier && <p className="text-sm text-gray-400">Associated Supplier: {supplier.name} ({supplier.location})</p>}
      <p className="text-sm text-gray-300 mt-1">Impact: {risk.impact}</p>
      <p className="text-sm text-gray-400">Likelihood: {(risk.likelihood * 100).toFixed(0)}%</p>
      {apiKeyConfigured && (
         <button 
          onClick={() => onAnalyze(risk)}
          className="mt-3 flex items-center text-sm bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-2 px-3 rounded-md transition duration-150 ease-in-out"
        >
          <SparklesIcon className="w-4 h-4 mr-2" />
          Analyze with AI
        </button>
      )}
    </div>
  );
};

const RiskAssessmentView: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [modalSources, setModalSources] = useState<GroundingChunk[] | undefined>(undefined);


  const handleAnalyzeRisk = useCallback(async (risk: Risk) => {
    if (!IS_API_KEY_CONFIGURED) {
      setError(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalTitle("API Key Error");
      setModalContent(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalOpen(true);
      return;
    }

    setIsLoading(true);
    setError(null);
    setModalOpen(true);
    setModalTitle(`AI Analysis: ${risk.description.substring(0,30)}...`);
    setModalContent('');
    setModalSources(undefined);

    const supplier = MOCK_SUPPLIERS.find(s => s.id === risk.supplierId);
    const prompt = `Analyze the following supply chain sustainability risk and provide mitigation strategies.
Risk Description: "${risk.description}"
Category: ${risk.category}
Severity: ${risk.severity}
Likelihood: ${(risk.likelihood * 100).toFixed(0)}%
Potential Impact: ${risk.impact}
${supplier ? `Associated Supplier: ${supplier.name}, located in ${supplier.location}, dealing with materials: ${supplier.materials.join(', ')}.` : ''}

Provide a concise analysis covering:
1. Key contributing factors to this risk.
2. Potential cascading effects if unaddressed.
3. 3-5 actionable mitigation strategies, with brief explanations.
Consider if this information is recent and if Google Search might be helpful.
`;
    
    try {
      const result = await generateText(prompt, true); // Using Google Search for risk analysis
      setModalContent(result.text);
      if (result.candidates && result.candidates[0]?.groundingMetadata?.groundingChunks) {
        setModalSources(result.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to get analysis from AI.');
      setModalContent(e.message || 'Failed to get analysis from AI.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="p-8">
      <h2 className="text-3xl font-semibold text-white mb-6">Risk Assessment</h2>
      
      {!IS_API_KEY_CONFIGURED && (
        <div className="mb-6 p-4 bg-yellow-900 border border-yellow-700 text-yellow-200 rounded-md">
          {GEMINI_API_KEY_ERROR_MESSAGE} AI features for analysis are disabled.
        </div>
      )}

      {MOCK_RISKS.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {MOCK_RISKS.map(risk => (
            <RiskItem key={risk.id} risk={risk} onAnalyze={handleAnalyzeRisk} apiKeyConfigured={IS_API_KEY_CONFIGURED} />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-400 mt-10">No risks identified at the moment.</p>
      )}

      <GeminiResponseModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        content={modalContent}
        isLoading={isLoading}
        error={error}
        sources={modalSources}
      />
    </div>
  );
};

export default RiskAssessmentView;
