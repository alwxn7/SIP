
import React from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { ChartDataPoint, TimeSeriesDataPoint } from '../types';

interface ChartComponentProps {
  title: string;
  data: ChartDataPoint[] | TimeSeriesDataPoint[];
  type: 'bar' | 'line' | 'pie';
  dataKey: string; // key for the value in data objects
  nameKey?: string; // key for the name/label in data objects (used for XAxis in bar/line, name in Pie)
}

const COLORS = ['#059669', '#065f46', '#047857', '#34d399', '#6ee7b7']; // Emerald shades

const ChartComponent: React.FC<ChartComponentProps> = ({ title, data, type, dataKey, nameKey = 'name' }) => {
  return (
    <div className="bg-base-200 p-6 rounded-xl shadow-lg h-96">
      <h3 className="text-lg font-semibold text-gray-200 mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height="85%">
        {type === 'bar' && Array.isArray(data) && data.every(d => 'name' in d && 'value' in d) && (
          <BarChart data={data as ChartDataPoint[]}>
            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
            <XAxis dataKey={nameKey} stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', borderRadius: '0.5rem' }} itemStyle={{ color: '#d1d5db' }}/>
            <Legend />
            <Bar dataKey={dataKey} fill="#059669" radius={[4, 4, 0, 0]} />
          </BarChart>
        )}
        {type === 'line' && Array.isArray(data) && data.every(d => 'date' in d && 'value' in d) && (
          <LineChart data={data as TimeSeriesDataPoint[]}>
            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
            <XAxis dataKey="date" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', borderRadius: '0.5rem' }} itemStyle={{ color: '#d1d5db' }} />
            <Legend />
            <Line type="monotone" dataKey={dataKey} stroke="#059669" strokeWidth={2} activeDot={{ r: 6 }} />
          </LineChart>
        )}
        {type === 'pie' && Array.isArray(data) && data.every(d => 'name' in d && 'value' in d) && (
           <PieChart>
            <Pie
              data={data as ChartDataPoint[]}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={100}
              fill="#8884d8"
              dataKey={dataKey}
              nameKey={nameKey}
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {(data as ChartDataPoint[]).map((_entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', borderRadius: '0.5rem' }} itemStyle={{ color: '#d1d5db' }}/>
            <Legend />
          </PieChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default ChartComponent;
