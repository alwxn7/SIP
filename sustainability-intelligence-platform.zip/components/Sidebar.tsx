import React from 'react';
import { NavigationItem } from '../types';
import { DashboardIcon, SupplyChainIcon, RiskIcon, OpportunityIcon, EmissionsIcon, RouteIcon, SparklesIcon } from './icons';
import { APP_TITLE } from '../constants';


interface SidebarProps {
  activeItem: NavigationItem;
  onNavigate: (item: NavigationItem) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeItem, onNavigate }) => {
  const navItems = [
    { name: NavigationItem.Dashboard, icon: DashboardIcon },
    { name: NavigationItem.SupplyChain, icon: SupplyChainIcon },
    { name: NavigationItem.RiskAssessment, icon: RiskIcon },
    { name: NavigationItem.OpportunityFinder, icon: OpportunityIcon },
    { name: NavigationItem.EmissionsEstimator, icon: EmissionsIcon },
    { name: NavigationItem.GreenerRoutes, icon: RouteIcon },
  ];

  return (
    <div className="w-64 bg-base-200 h-screen p-5 flex flex-col fixed top-0 left-0 shadow-lg">
      <div className="flex items-center mb-10">
        <SparklesIcon className="w-10 h-10 text-brand-primary mr-3"/>
        <h1 className="text-xl font-bold text-white">{APP_TITLE.split(" ").slice(0,2).join(" ")}</h1>
      </div>
      <nav>
        <ul>
          {navItems.map((item) => (
            <li key={item.name} className="mb-3">
              <button
                onClick={() => onNavigate(item.name)}
                className={`w-full flex items-center py-3 px-4 rounded-lg transition-colors duration-200 ease-in-out
                            ${activeItem === item.name 
                              ? 'bg-brand-primary text-white shadow-md' 
                              : 'text-gray-400 hover:bg-base-300 hover:text-white'}`}
              >
                <item.icon className="w-5 h-5 mr-3" />
                <span className="text-sm font-medium">{item.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
      <div className="mt-auto text-center text-xs text-gray-500">
        <p>&copy; {new Date().getFullYear()} SustaiChain Intel</p>
        <p>Powered by Gemini</p>
      </div>
    </div>
  );
};

export default Sidebar;