import React, { useState, useCallback } from 'react';
import { MOCK_SUPPLIERS, IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { Supplier, GroundingChunk } from '../types';
import { generateText } from '../services/geminiService';
import GeminiResponseModal from './GeminiResponseModal';
import LoadingSpinner from './LoadingSpinner';
import { SparklesIcon } from './icons';

interface SupplyChainListItemProps {
  supplier: Supplier;
  onAnalyzeSupplier: (supplier: Supplier) => void;
  apiKeyConfigured: boolean;
}

const SupplyChainListItem: React.FC<SupplyChainListItemProps> = ({ supplier, onAnalyzeSupplier, apiKeyConfigured }) => {
  const riskColor = supplier.riskLevel === 'High' ? 'text-red-400' : supplier.riskLevel === 'Medium' ? 'text-yellow-400' : 'text-emerald-400';
  return (
    <div className="bg-base-200 p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 flex flex-col justify-between">
      <div>
        <h3 className="text-lg font-semibold text-white">{supplier.name}</h3>
        <p className="text-sm text-gray-400">Tier: {supplier.tier} | Location: {supplier.location}</p>
        <p className="text-sm text-gray-300 mt-1">Key Materials: {supplier.materials.join(', ')}</p>
        <div className="mt-2 flex justify-between items-center">
          <p className="text-sm">Sustainability Score: <span className="font-bold text-white">{supplier.sustainabilityScore}/100</span></p>
          <p className={`text-sm font-semibold ${riskColor}`}>Risk: {supplier.riskLevel}</p>
        </div>
        <div className="mt-2 text-xs text-gray-400">
          <span>CO2: {supplier.carbonFootprint} tCO2e</span> | <span>H2O: {supplier.waterUsage} m³</span>
        </div>
      </div>
      {apiKeyConfigured && (
        <button
          onClick={() => onAnalyzeSupplier(supplier)}
          className="mt-3 w-full flex items-center justify-center text-sm bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-2 px-3 rounded-md transition duration-150 ease-in-out"
        >
          <SparklesIcon className="w-4 h-4 mr-2" />
          AI Re-evaluate Score
        </button>
      )}
    </div>
  );
};

const SupplyChainView: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTier, setFilterTier] = useState<number | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [modalSources, setModalSources] = useState<GroundingChunk[] | undefined>(undefined);

  const handleAnalyzeSupplier = useCallback(async (supplier: Supplier) => {
    if (!IS_API_KEY_CONFIGURED) {
      setError(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalTitle("API Key Error");
      setModalContent(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalOpen(true);
      return;
    }

    setIsLoading(true);
    setError(null);
    setModalOpen(true);
    setModalTitle(`AI Analysis: ${supplier.name}`);
    setModalContent('');
    setModalSources(undefined);

    const prompt = `
      Re-assess the sustainability score (0-100) and provide a brief qualitative analysis for the following supplier:
      Name: "${supplier.name}"
      Tier: ${supplier.tier}
      Location: "${supplier.location}"
      Key Materials: ${supplier.materials.join(', ')}
      Current Reported Score: ${supplier.sustainabilityScore}/100
      Current Reported Carbon Footprint: ${supplier.carbonFootprint} tCO2e
      Current Reported Water Usage: ${supplier.waterUsage} m³
      Known Risk Level: ${supplier.riskLevel}

      Focus your analysis on:
      1. Environmental performance (considering materials, reported carbon/water, location-specific environmental factors like energy mix or water stress if inferable).
      2. Social responsibility (based on typical industry/location concerns if specific data is absent, e.g., labor practices for certain industries/regions).
      3. Governance/Transparency (inferred from the completeness of data and general practices).

      Provide:
      a. An updated estimated sustainability score (0-100).
      b. A short summary of your assessment (3-4 sentences), highlighting key strengths and areas for improvement.
      c. Mention any key assumptions made.

      Use Google Search for recent news, ESG reports, or location-specific sustainability factors related to this supplier's industry (e.g., textiles in Vietnam, metals in China) to inform your assessment. Cite key sources if possible.
    `;
    
    try {
      const result = await generateText(prompt, true);
      setModalContent(result.text);
      if (result.candidates && result.candidates[0]?.groundingMetadata?.groundingChunks) {
        setModalSources(result.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to get analysis from AI.');
      setModalContent(e.message || 'Failed to get analysis from AI.');
    } finally {
      setIsLoading(false);
    }
  }, []);


  const filteredSuppliers = MOCK_SUPPLIERS.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          supplier.materials.join(', ').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTier = filterTier ? supplier.tier === filterTier : true;
    return matchesSearch && matchesTier;
  });

  return (
    <div className="p-8">
      <h2 className="text-3xl font-semibold text-white mb-6">Supply Chain Overview</h2>
      
      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <input 
          type="text"
          placeholder="Search suppliers..."
          className="flex-grow p-3 bg-base-200 border border-base-300 rounded-lg text-white focus:ring-2 focus:ring-brand-primary outline-none"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <select 
          className="p-3 bg-base-200 border border-base-300 rounded-lg text-white focus:ring-2 focus:ring-brand-primary outline-none"
          value={filterTier ?? ''}
          onChange={(e) => setFilterTier(e.target.value ? parseInt(e.target.value) : null)}
        >
          <option value="">All Tiers</option>
          <option value="1">Tier 1</option>
          <option value="2">Tier 2</option>
          <option value="3">Tier 3</option>
        </select>
      </div>

      {!IS_API_KEY_CONFIGURED && (
        <div className="mb-6 p-4 bg-yellow-900 border border-yellow-700 text-yellow-200 rounded-md">
          {GEMINI_API_KEY_ERROR_MESSAGE} AI features for supplier analysis are disabled.
        </div>
      )}

      {filteredSuppliers.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSuppliers.map(supplier => (
            <SupplyChainListItem 
              key={supplier.id} 
              supplier={supplier} 
              onAnalyzeSupplier={handleAnalyzeSupplier}
              apiKeyConfigured={IS_API_KEY_CONFIGURED}
            />
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-400 mt-10">No suppliers found matching your criteria.</p>
      )}

       <GeminiResponseModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        content={modalContent}
        isLoading={isLoading}
        error={error}
        sources={modalSources}
      />
    </div>
  );
};

export default SupplyChainView;