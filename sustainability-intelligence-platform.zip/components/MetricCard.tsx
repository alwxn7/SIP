
import React from 'react';
import { SustainabilityMetric } from '../types';
import { TrendUpIcon, TrendDownIcon } from './icons';

interface MetricCardProps {
  metric: SustainabilityMetric;
}

const MetricCard: React.FC<MetricCardProps> = ({ metric }) => {
  const TrendIcon = metric.trend === 'up' ? TrendUpIcon : metric.trend === 'down' ? TrendDownIcon : null;
  const trendColor = metric.trend === 'up' ? 'text-emerald-400' : metric.trend === 'down' ? 'text-red-400' : 'text-gray-400';

  return (
    <div className="bg-base-200 p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-300">
      <h3 className="text-lg font-semibold text-gray-200 mb-1">{metric.name}</h3>
      <p className="text-4xl font-bold text-white mb-2">
        {metric.value}
        <span className="text-xl text-gray-400 ml-1">{metric.unit}</span>
      </p>
      <div className="flex items-center text-sm text-gray-400">
        {TrendIcon && <TrendIcon className={`w-5 h-5 mr-1 ${trendColor}`} />}
        <span className={trendColor}>
          {metric.trend ? `${metric.trend.charAt(0).toUpperCase() + metric.trend.slice(1)}` : 'Stable'}
        </span>
        <span className="ml-auto text-xs">Last updated: {metric.lastUpdated}</span>
      </div>
    </div>
  );
};

export default MetricCard;
