import React, { useState, useCallback } from 'react';
import { generateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import GeminiResponseModal from './GeminiResponseModal';
import { IS_API_KEY_CONFIGURED, GEMINI_API_KEY_ERROR_MESSAGE } from '../constants';
import { SparklesIcon } from './icons';
import { GreenerRouteRequest, GroundingChunk } from '../types';

const GreenerRoutesView: React.FC = () => {
  const [formData, setFormData] = useState<GreenerRouteRequest>({
    origin: '',
    destination: '',
    shipmentType: 'Standard Container',
    shipmentWeightTonnes: 0,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState('');
  const [modalSources, setModalSources] = useState<GroundingChunk[] | undefined>(undefined);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'shipmentWeightTonnes' ? parseFloat(value) : value }));
  };

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!IS_API_KEY_CONFIGURED) {
      setError(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalTitle("API Key Error");
      setModalContent(GEMINI_API_KEY_ERROR_MESSAGE);
      setModalOpen(true);
      return;
    }
    if (!formData.origin || !formData.destination || formData.shipmentWeightTonnes <= 0) {
        setError("Please fill in all required fields with valid values.");
        setModalTitle("Input Error");
        setModalContent("Please fill in all required fields: Origin, Destination, and Shipment Weight (>0).");
        setModalOpen(true);
        return;
    }

    setIsLoading(true);
    setError(null);
    setModalOpen(true);
    setModalTitle(`Greener Routes: ${formData.origin} to ${formData.destination}`);
    setModalContent('');
    setModalSources(undefined);

    const prompt = `
      Recommend greener transportation routes for a shipment with the following details:
      Origin: "${formData.origin}"
      Destination: "${formData.destination}"
      Shipment Type: ${formData.shipmentType}
      Shipment Weight: ${formData.shipmentWeightTonnes} tonnes

      Suggest 2-3 alternative routes, prioritizing lower carbon emissions. For each route, specify:
      1. Key Transportation modes involved (e.g., Sea + Rail, predominantly Rail, Intermodal).
      2. Estimated transit time (approximate range, e.g., 25-30 days).
      3. Estimated carbon emissions (in kg CO2e or tonnes CO2e, clearly state unit).
      4. Key benefits of this greener route (e.g., reduced emissions, potential cost savings, reliability).
      5. Potential drawbacks or considerations (e.g., longer transit time, transhipment complexity).

      Use Google Search for current logistics information, typical routes, intermodal options, and emission factors for different transport modes. Cite key sources if possible.
      Present the recommendations in a clear, comparable format. If possible, provide a baseline comparison against a common, less green route (e.g. all-sea or all-air if applicable).
    `;

    try {
      const result = await generateText(prompt, true);
      setModalContent(result.text);
      if (result.candidates && result.candidates[0]?.groundingMetadata?.groundingChunks) {
        setModalSources(result.candidates[0].groundingMetadata.groundingChunks);
      }
    } catch (e: any) {
      setError(e.message || 'Failed to get greener route recommendations from AI.');
      setModalContent(e.message || 'Failed to get greener route recommendations from AI.');
    } finally {
      setIsLoading(false);
    }
  }, [formData]);

  const inputClass = "w-full p-3 bg-base-300 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-brand-primary outline-none placeholder-gray-500";
  const labelClass = "block text-sm font-medium text-gray-300 mb-1";

  return (
    <div className="p-8">
      <h2 className="text-3xl font-semibold text-white mb-6">Greener Route Recommendations</h2>
      
      <form onSubmit={handleSubmit} className="bg-base-200 p-6 rounded-xl shadow-lg space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="origin" className={labelClass}>Origin *</label>
            <input type="text" name="origin" id="origin" value={formData.origin} onChange={handleInputChange} className={inputClass} placeholder="e.g., Shanghai, China" required />
          </div>
          <div>
            <label htmlFor="destination" className={labelClass}>Destination *</label>
            <input type="text" name="destination" id="destination" value={formData.destination} onChange={handleInputChange} className={inputClass} placeholder="e.g., Rotterdam, Netherlands" required />
          </div>
          <div>
            <label htmlFor="shipmentType" className={labelClass}>Shipment Type *</label>
            <select name="shipmentType" id="shipmentType" value={formData.shipmentType} onChange={handleInputChange} className={inputClass} required>
              <option value="Standard Container">Standard Container (FCL/LCL)</option>
              <option value="Bulk">Bulk Cargo</option>
              <option value="Perishable">Perishable Goods (Reefer)</option>
              <option value="Hazardous">Hazardous Materials</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div>
            <label htmlFor="shipmentWeightTonnes" className={labelClass}>Shipment Weight (tonnes) *</label>
            <input type="number" name="shipmentWeightTonnes" id="shipmentWeightTonnes" value={formData.shipmentWeightTonnes} onChange={handleInputChange} className={inputClass} placeholder="e.g., 20" min="0.01" step="0.01" required />
          </div>
        </div>
        
        {!IS_API_KEY_CONFIGURED && (
          <div className="p-3 bg-yellow-900 border border-yellow-700 text-yellow-200 rounded-md text-sm">
            {GEMINI_API_KEY_ERROR_MESSAGE} AI features for route recommendation are disabled.
          </div>
        )}

        <button 
          type="submit"
          disabled={isLoading || !IS_API_KEY_CONFIGURED}
          className="w-full flex items-center justify-center bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-3 px-4 rounded-lg transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner /> : <><SparklesIcon className="w-5 h-5 mr-2" /> Find Greener Routes with AI</>}
        </button>
      </form>

      <GeminiResponseModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={modalTitle}
        content={modalContent}
        isLoading={isLoading}
        error={error}
        sources={modalSources}
      />
    </div>
  );
};

export default GreenerRoutesView;